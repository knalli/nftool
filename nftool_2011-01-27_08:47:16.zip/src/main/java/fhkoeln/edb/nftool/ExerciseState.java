package fhkoeln.edb.nftool;


public enum ExerciseState {

    INTRO, KEYS, NORMALFORM1, NORMALFORM2, NORMALFORM3, SOLVED
}
