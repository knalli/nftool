package fhkoeln.edb.nftool;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import fhkoeln.edb.nftool.Task;

@RooDataOnDemand(entity = Task.class)
public class TaskDataOnDemand {
}
