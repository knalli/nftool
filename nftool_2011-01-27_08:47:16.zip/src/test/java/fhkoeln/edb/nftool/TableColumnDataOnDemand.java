package fhkoeln.edb.nftool;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import fhkoeln.edb.nftool.TableColumn;

@RooDataOnDemand(entity = TableColumn.class)
public class TableColumnDataOnDemand {
}
