package fhkoeln.edb.nftool;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import fhkoeln.edb.nftool.TableRow;

@RooDataOnDemand(entity = TableRow.class)
public class TableRowDataOnDemand {
}
