package fhkoeln.edb.nftool;

import org.springframework.roo.addon.test.RooIntegrationTest;
import fhkoeln.edb.nftool.TableRow;
import org.junit.Test;

@RooIntegrationTest(entity = TableRow.class)
public class TableRowIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
