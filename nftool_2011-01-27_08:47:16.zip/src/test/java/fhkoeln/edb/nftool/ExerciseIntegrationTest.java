package fhkoeln.edb.nftool;

import org.springframework.roo.addon.test.RooIntegrationTest;
import fhkoeln.edb.nftool.Exercise;

import org.junit.Assert;
import org.junit.Test;

@RooIntegrationTest(entity = Exercise.class)
public class ExerciseIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
    
}
