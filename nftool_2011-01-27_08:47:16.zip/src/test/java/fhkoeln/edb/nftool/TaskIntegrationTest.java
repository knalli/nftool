package fhkoeln.edb.nftool;

import org.springframework.roo.addon.test.RooIntegrationTest;
import fhkoeln.edb.nftool.Task;
import org.junit.Test;

@RooIntegrationTest(entity = Task.class)
public class TaskIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
