package fhkoeln.edb.nftool;

import org.springframework.roo.addon.test.RooIntegrationTest;
import fhkoeln.edb.nftool.TableColumn;
import org.junit.Test;

@RooIntegrationTest(entity = TableColumn.class)
public class TableColumnIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
