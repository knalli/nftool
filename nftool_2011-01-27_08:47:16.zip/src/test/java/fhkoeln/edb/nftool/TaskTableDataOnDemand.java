package fhkoeln.edb.nftool;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import fhkoeln.edb.nftool.TaskTable;

@RooDataOnDemand(entity = TaskTable.class)
public class TaskTableDataOnDemand {
}
