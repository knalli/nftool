package fhkoeln.edb.nftool;

import org.springframework.roo.addon.test.RooIntegrationTest;
import fhkoeln.edb.nftool.TaskTable;
import org.junit.Test;

@RooIntegrationTest(entity = TaskTable.class)
public class TaskTableIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
