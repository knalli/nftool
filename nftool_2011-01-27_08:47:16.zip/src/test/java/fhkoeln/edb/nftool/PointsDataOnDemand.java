package fhkoeln.edb.nftool;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import fhkoeln.edb.nftool.Points;

@RooDataOnDemand(entity = Points.class)
public class PointsDataOnDemand {
}
