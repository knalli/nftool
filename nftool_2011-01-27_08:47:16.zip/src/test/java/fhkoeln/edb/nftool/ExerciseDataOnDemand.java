package fhkoeln.edb.nftool;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import fhkoeln.edb.nftool.Exercise;

@RooDataOnDemand(entity = Exercise.class)
public class ExerciseDataOnDemand {
}
