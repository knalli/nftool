package fhkoeln.edb.nftool;

import org.springframework.roo.addon.test.RooIntegrationTest;
import fhkoeln.edb.nftool.Points;
import org.junit.Test;

@RooIntegrationTest(entity = Points.class)
public class PointsIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
